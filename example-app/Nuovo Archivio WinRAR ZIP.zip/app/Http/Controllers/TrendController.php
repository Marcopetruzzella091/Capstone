<?php

namespace App\Http\Controllers;

use App\Models\Trend;
use App\Http\Requests\StoreTrendRequest;
use App\Http\Requests\UpdateTrendRequest;

class TrendController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTrendRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Trend $trend)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Trend $trend)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTrendRequest $request, Trend $trend)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Trend $trend)
    {
        //
    }
}
