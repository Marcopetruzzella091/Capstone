<?php

namespace App\Http\Controllers;

use App\Models\Follower;
use App\Http\Requests\StoreFollowerRequest;
use App\Http\Requests\UpdateFollowerRequest;

class FollowerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreFollowerRequest $request)
    {    $request ->auth;
         $request ->user;

        // Controlla se esiste già un like con lo stesso post_id e user_id
        $existingfollow = Follower::where('user_id',  $request ->auth)
        ->where('user_id_following', $request ->user)
        ->first();

            // Se esiste già un like, elimina completamente il like
            if ($existingfollow) {
            $existingfollow->delete();
            } else {
            // Se non esiste un like, crea un nuovo like con lo stato true
            $like = Follower::create([
            'user_id' => $request ->auth,
            'user_id_following' => $request ->user,
            
            ]);
            }
            ;



    }

    /**
     * Display the specified resource.
     */
    public function show(Follower $follower)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Follower $follower)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateFollowerRequest $request, Follower $follower)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Follower $follower)
    {
        //
    }
}
